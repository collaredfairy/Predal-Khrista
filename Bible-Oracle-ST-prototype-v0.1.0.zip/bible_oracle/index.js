import { eventSource, event_types, saveSettingsDebounced, extension_settings } from '../../../../script.js';

const MODULE = 'bible-oracle';
const VERSION = '0.1.0';
const KJV_URL = 'https://raw.githubusercontent.com/churchstudio-org/openbible/main/KJV/bible.json';
const DEFAULT_BOOKS = ['Genesis','Exodus','Leviticus','Numbers','Deuteronomy','Joshua','Judges','Ruth','1 Samuel','2 Samuel','1 Kings','2 Kings','1 Chronicles','2 Chronicles','Ezra','Nehemiah','Esther','Job','Psalms','Proverbs','Ecclesiastes','Song of Solomon','Isaiah','Jeremiah','Lamentations','Ezekiel','Daniel','Hosea','Joel','Amos','Obadiah','Jonah','Micah','Nahum','Habakkuk','Zephaniah','Haggai','Zechariah','Malachi','Matthew','Mark','Luke','John','Acts','Romans','1 Corinthians','2 Corinthians','Galatians','Ephesians','Philippians','Colossians','1 Thessalonians','2 Thessalonians','1 Timothy','2 Timothy','Titus','Philemon','Hebrews','James','1 Peter','2 Peter','1 John','2 John','3 John','Jude','Revelation'];

const THEMES = [
  'Sin','Repentance','Forgiveness','Pride','Humility','Hypocrisy','Judgment','Wrath','Mercy','Death','Resurrection',
  'Suffering','Fear','Faith','Doubt','Abandonment','Obedience','Rebellion','Sacrifice','Blood','Purity','Uncleanness',
  'Darkness','Light','Fire','Water','Hunger','Thirst','Wilderness','Exile','Betrayal','Persecution','Temptation',
  'Demons','Miracles','Prophecy','Apocalypse','Creation','Vanity','Wisdom','Love','Hatred','Envy','Greed','Justice',
  'Healing','Comfort','Hope','Despair','Foolishness','Death','Life'
];

let state = { corpus:null, verses:[], loaded:false, favorites:[], selectedTheme:'', lastResults:[] };

function cleanMarkup(s){
  return String(s ?? '').replace(/[{}]/g,'').replace(/\[([^\]]+)\]/g,'$1').replace(/\s+/g,' ').trim();
}

function flattenCorpus(data){
  const out=[];
  const books = Array.isArray(data) ? data : (data.books || data);
  if (Array.isArray(books)) {
    for (const b of books) {
      const name=b.name||b.book||b.title;
      const chapters=b.chapters||{};
      for (const [ch, verses] of Object.entries(chapters)) for (const [v,t] of Object.entries(verses)) out.push({ref:`${name} ${ch}:${v}`,book:name,chapter:+ch,verse:+v,text:cleanMarkup(t)});
  }} else if (typeof books==='object') {
    for (const [name,b] of Object.entries(books)) {
      const chapters=b.chapters||b;
      for (const [ch, verses] of Object.entries(chapters)) if (typeof verses==='object') for (const [v,t] of Object.entries(verses)) out.push({ref:`${name} ${ch}:${v}`,book:name,chapter:+ch,verse:+v,text:cleanMarkup(t)});
    }
  }
  return out.filter(x=>x.book&&x.text);
}

function esc(s){return String(s).replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\\':'&#39;'}[c]));}
function getPanel(){return document.getElementById('bible_oracle_panel');}
function status(t){const e=document.getElementById('bo_status'); if(e)e.textContent=t;}

async function loadCorpus(){
  if(state.loaded) return true;
  status('Loading KJV corpus…');
  try {
    const r=await fetch(KJV_URL,{cache:'force-cache'});
    if(!r.ok) throw new Error(`HTTP ${r.status}`);
    state.corpus=await r.json();
    state.verses=flattenCorpus(state.corpus);
    if(!state.verses.length) throw new Error('No verses found in corpus');
    state.loaded=true;
    status(`KJV loaded: ${state.verses.length.toLocaleString()} verses`);
    return true;
  } catch(e){
    console.error('[Bible Oracle]',e);
    status('Could not download KJV. Use Import JSON below.');
    toastr.error('Bible Oracle could not download the KJV corpus.');
    return false;
  }
}

function renderResults(results, title='Results'){
  state.lastResults=results;
  const box=document.getElementById('bo_results'); if(!box)return;
  if(!results.length){box.innerHTML='<div class="bo_empty">No passages found.</div>';return;}
  box.innerHTML=`<div class="bo_result_title">${esc(title)}</div>`+results.map((x,i)=>`<article class="bo_result" data-i="${i}">
    <div class="bo_ref">${esc(x.ref)}</div>
    <div class="bo_text">${esc(x.text)}</div>
    ${x.reason?`<div class="bo_reason">${esc(x.reason)}</div>`:''}
    <div class="bo_actions"><button class="bo_copy" data-i="${i}">Copy</button><button class="bo_fav" data-i="${i}">${state.favorites.some(f=>f.ref===x.ref)?'★':'☆'}</button></div>
  </article>`).join('');
  box.querySelectorAll('.bo_copy').forEach(b=>b.addEventListener('click',()=>navigator.clipboard.writeText(`${state.lastResults[b.dataset.i].ref}\n\n${state.lastResults[b.dataset.i].text}`)));
  box.querySelectorAll('.bo_fav').forEach(b=>b.addEventListener('click',()=>toggleFav(state.lastResults[b.dataset.i])));
}

function literalSearch(q){
  const terms=q.toLowerCase().split(/\s+/).filter(Boolean);
  return state.verses.map(v=>({v,score:terms.reduce((s,t)=>s+(v.text.toLowerCase().includes(t)?1:0),0)})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,30).map(x=>x.v);
}

async function analyzeChat(){
  if(!await loadCorpus())return;
  const ctx=window.SillyTavern?.getContext?.();
  const chat=ctx?.chat||[];
  const recent=chat.slice(-20).map(m=>`${m.name||m.role}: ${m.mes||m.content||''}`).join('\n\n');
  if(!recent.trim()){toastr.warning('No chat messages available.');return;}
  status('Asking the current ST model to identify relevant Scripture…');
  const {generateRaw}=ctx;
  const candidates=state.verses.length>0 ? lexicalCandidates(recent,80) : [];
  const candidateText=candidates.map((v,i)=>`[${i}] ${v.ref}\n${v.text}`).join('\n\n');
  const prompt=`You are a biblical retrieval assistant for an RP writer. Analyze the recent roleplay below and select the most contextually useful Bible passages from the CANDIDATES.\n\nCRITICAL RULES:\n- You may ONLY recommend passages from CANDIDATES.\n- Never invent a verse, reference, quotation, or wording.\n- Return JSON only.\n- Prefer passages that genuinely resonate with the situation, not merely keyword matches.\n- Give 3-6 recommendations.\n\nCURRENT RP:\n${recent}\n\nCANDIDATES:\n${candidateText}`;
  try {
    const raw=await generateRaw({systemPrompt:'You select real Bible passages from a supplied corpus. You never invent Scripture.',prompt,jsonSchema:{name:'BibleRecommendations',strict:true,value:{type:'object',properties:{items:{type:'array',items:{type:'object',properties:{candidate:{type:'integer'},reason:{type:'string'}},required:['candidate','reason']}}},required:['items']}}});
    const parsed=JSON.parse(raw);
    const results=(parsed.items||[]).map(x=>({...candidates[x.candidate],reason:x.reason})).filter(x=>x&&x.ref);
    renderResults(results,'Suggested passages for this scene');
    status(`Found ${results.length} suggestions.`);
  } catch(e){console.error(e);toastr.error('Bible analysis failed.');status('Analysis failed.');}
}

function lexicalCandidates(text,n=80){
  const stop=new Set('the and that this with from have has was were are for you your they them into about then than what when where while would could should just like been being there their his her she him our out not but all can will one two had did does its who why how'.split(' '));
  const words=(text.toLowerCase().match(/[a-z]{3,}/g)||[]).filter(w=>!stop.has(w));
  const freq={}; for(const w of words)freq[w]=(freq[w]||0)+1;
  const terms=Object.keys(freq).sort((a,b)=>freq[b]-freq[a]).slice(0,35);
  return state.verses.map(v=>{const t=v.text.toLowerCase();let score=0;for(const w of terms)if(t.includes(w))score+=freq[w];return {v,score};}).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,n).map(x=>x.v);
}

function themeSearch(theme){
  const q=theme.toLowerCase();
  const aliases={judgment:'judge judgment condemn condemned wrath judgement',pride:'proud pride arrogant highminded',sin:'sin sinner transgression iniquity wicked',death:'death die dead grave perish',mercy:'mercy merciful compassion',betrayal:'betray betrayed treacherous',fear:'fear afraid afraid',comfort:'comfort consolation',forgiveness:'forgive forgiven forgiveness',blood:'blood slain murder',darkness:'dark darkness',light:'light',wisdom:'wisdom wise fool foolish'};
  const terms=(aliases[q]||q).split(/\s+/);
  return state.verses.map(v=>{const t=v.text.toLowerCase();let score=0;for(const w of terms)if(t.includes(w))score++;return {v,score};}).filter(x=>x.score).sort((a,b)=>b.score-a.score).slice(0,30).map(x=>x.v);
}

function toggleFav(v){
  const i=state.favorites.findIndex(x=>x.ref===v.ref); if(i>=0)state.favorites.splice(i,1); else state.favorites.push(v);
  extension_settings[MODULE].favorites=state.favorites; saveSettingsDebounced(); renderResults(state.lastResults,'Results');
}

function buildUI(){
  if(getPanel())return;
  const html=`<div id="bible_oracle_panel" class="bible_oracle_panel">
    <div class="bo_head"><div><b>📖 Bible Oracle</b><small>KJV retrieval assistant</small></div><button id="bo_close">×</button></div>
    <div class="bo_tabs"><button class="bo_tab active" data-tab="catalogue">Catalogue</button><button class="bo_tab" data-tab="oracle">Current scene</button><button class="bo_tab" data-tab="favorites">Favorites</button></div>
    <div id="bo_catalogue" class="bo_tabbody">
      <div class="bo_note">Choose a theme. Results come from the actual KJV corpus, not generated quotations.</div>
      <div class="bo_grid">${THEMES.map(t=>`<button class="bo_theme" data-theme="${esc(t)}">${esc(t)}</button>`).join('')}</div>
      <div class="bo_search"><input id="bo_search_input" placeholder="Search Bible words…"><button id="bo_search_btn">Search</button></div>
    </div>
    <div id="bo_oracle" class="bo_tabbody" style="display:none"><div class="bo_note">Reads the recent ST chat, finds candidate passages locally, then asks your selected ST model to rank only those real passages.</div><button id="bo_analyze" class="bo_primary">Analyze current scene</button></div>
    <div id="bo_favorites" class="bo_tabbody" style="display:none"><div class="bo_note">Your personally saved passages.</div><button id="bo_show_favs">Show favorites</button></div>
    <div id="bo_results"></div>
    <div class="bo_footer"><span id="bo_status">KJV not loaded</span><label class="bo_import">Import KJV JSON<input id="bo_import_file" type="file" accept=".json,application/json" hidden></label></div>
  </div>`;
  document.body.insertAdjacentHTML('beforeend',html);
  $('#bo_close').on('click',()=>getPanel().remove());
  $('.bo_tab').on('click',function(){const tab=$(this).data('tab');$('.bo_tab').removeClass('active');$(this).addClass('active');$('.bo_tabbody').hide();$(`#bo_${tab}`).show();});
  $('.bo_theme').on('click',async function(){await loadCorpus();state.selectedTheme=$(this).data('theme');renderResults(themeSearch(state.selectedTheme),state.selectedTheme);});
  $('#bo_search_btn').on('click',async()=>{await loadCorpus();const q=$('#bo_search_input').val();renderResults(literalSearch(q),`Search: ${q}`);});
  $('#bo_search_input').on('keydown',e=>{if(e.key==='Enter')$('#bo_search_btn').click();});
  $('#bo_analyze').on('click',analyzeChat);
  $('#bo_show_favs').on('click',()=>renderResults(state.favorites,'Favorites'));
  $('#bo_import_file').on('change',async e=>{const f=e.target.files[0];if(!f)return;try{state.corpus=JSON.parse(await f.text());state.verses=flattenCorpus(state.corpus);state.loaded=true;status(`Imported ${state.verses.length.toLocaleString()} verses`);toastr.success('KJV corpus imported.');}catch(err){toastr.error('Invalid Bible JSON.');}});
}

function addButton(){
  if($('#bible_oracle_launcher').length)return;
  const b=$('<div id="bible_oracle_launcher" class="menu_button interactable" title="Bible Oracle"><span>📖</span></div>');
  b.on('click',()=>{if(getPanel())getPanel().remove();else buildUI();});
  $('#extensions_settings').append(b);
}

async function init(){
  extension_settings[MODULE] ??= {favorites:[]};
  state.favorites=extension_settings[MODULE].favorites||[];
  addButton();
  console.log(`[Bible Oracle ${VERSION}] loaded`);
}

const $ = window.jQuery;
await init();
