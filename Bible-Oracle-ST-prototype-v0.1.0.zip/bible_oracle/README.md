# Bible Oracle for SillyTavern

Prototype v0.1.0.

## Features
- KJV corpus retrieved from the public-domain OpenBible JSON corpus on first use.
- Local literal keyword search.
- Theme catalogue with common biblical concepts.
- Current-scene mode: reads recent ST chat, creates local candidate passages, then asks the currently selected ST model to rank only those candidates.
- The model cannot supply Bible text itself. The displayed quotation always comes from the local/downloaded KJV corpus.
- Favorites stored in SillyTavern extension settings.
- Import KJV JSON manually if GitHub/raw access is unavailable.

## Install
Use SillyTavern Extensions -> Install Extension and install from this repository once you publish it, or place this folder under your third-party extensions directory.

This prototype has no server plugin and no API key of its own. LLM calls use SillyTavern's currently configured model through `generateRaw()`.

## Important
This is an experimental prototype. The semantic retrieval stage is intentionally simple in v0.1.0. The next version should add embeddings / semantic search, better context extraction, passage-range retrieval, and configurable translation corpora.
